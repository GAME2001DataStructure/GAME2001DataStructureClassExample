#include <iostream>

using namespace std;

class Node
{
   public:
      Node(int obj) : m_object(obj), m_next(NULL),
                      m_prev(NULL), m_child(NULL)
      {
         cout << "Node created!" << endl;
      }

      ~Node()
      {

      }

      void AddChild(Node *node)
      {

      }

      void AddSibling(Node *node)
      {

      }

      void DisplayTree()
      {


      }

      bool Search(int value)
      {

      }

   private:
      int m_object;
      Node *m_next, *m_prev, *m_child;
};


int main(int args, char *arg[])
{
   cout << "Simple Tree Data Structure" 
	    << endl << endl;

   // Manually create the tree...
   Node *root = new Node(1);
   Node *subTree1 = new Node(3);

   root->AddChild(new Node(2));

   subTree1->AddChild(new Node(5));
   subTree1->AddChild(new Node(6));

   root->AddChild(subTree1);
   root->AddChild(new Node(4));

   cout << endl;

   // Display the tree...
   cout << "Tree contents by level:" << endl;
   root->DisplayTree();
   cout << endl << endl;

   // Test searching...
   cout << "Searching for node 5: ";

   if(root->Search(5) == true)
      cout << "Node Found!" << endl;
   else
      cout << "Node NOT Found!" << endl;

   cout << "Searching for node 9: ";

   if(root->Search(9) == true)
      cout << "Node Found!" << endl;
   else
      cout << "Node NOT Found!" << endl;

   cout << endl;


   // Will delete entire tree...
   delete root;

   cout << endl << endl;

   return 1;
}