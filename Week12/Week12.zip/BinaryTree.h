#ifndef _BINARY_TREE_
#define _BINARY_TREE_

#include <iostream>

using namespace std;

template<typename T>
class BinaryTree;

template<typename T>
class Node
{
   friend class BinaryTree<T>;

   public:
      Node(T key) : m_key(key), m_left(NULL), m_right(NULL)
      {

      }

      ~Node()
      {
         if(m_left != NULL)
         {
           delete m_left;
           m_left = NULL;
         }

         if(m_right != NULL)
         {
           delete m_right;
           m_right = NULL;
         }
      }

      T GetKey()
      {
         return m_key;
      }

   private:
      T m_key;
      Node *m_left, *m_right;
};

template<typename T>
class BinaryTree
{
   public:
      BinaryTree() : m_root(NULL)
      {

      }

      ~BinaryTree()
      {
         if(m_root != NULL)
         {
           delete m_root;
           m_root = NULL;
         }
      }

      bool push(T key)
      {
         
      }

      bool search(T key)
      {
         
      }

      void remove(T key)
      {
        
      }

      void DisplayPreOrder()
      {
         DisplayPreOrder(m_root);
      }

      void DisplayPostOrder()
      {
         DisplayPostOrder(m_root);
      }

      void DisplayInOrder()
      {
         DisplayInOrder(m_root);
      }

   private:
      void DisplayPreOrder(Node<T> *node)
      {
         if(node != NULL)
         {
           cout << node->m_key << " ";

           DisplayPreOrder(node->m_left);
           DisplayPreOrder(node->m_right);
         }
      }

      void DisplayPostOrder(Node<T> *node)
      {
         if(node != NULL)
         {
           DisplayPostOrder(node->m_left);
           DisplayPostOrder(node->m_right);

           cout << node->m_key << " ";
         }
      }

      void DisplayInOrder(Node<T> *node)
      {
         if(node != NULL)
         {
           DisplayInOrder(node->m_left);

           cout << node->m_key << " ";

           DisplayInOrder(node->m_right);
         }
      }

   private:
      Node<T> *m_root;
};

#endif